package sussy.gui;

import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import sussy.SussyClient;
import sussy.config.ConfigManager;
import sussy.module.Category;
import sussy.module.Module;
import sussy.module.impl.ThemeModule;
import sussy.setting.BoolSetting;
import sussy.setting.NumberSetting;
import sussy.setting.Setting;

import java.util.*;

/**
 * Left click header + drag  = move panel      Right click header = collapse
 * Left click module         = toggle          Right click module = show settings
 * Drag a slider / click a checkbox to change settings. Everything saves automatically.
 */
public class ClickGuiScreen extends Screen {
    public static final Map<Category, int[]> POSITIONS = new EnumMap<>(Category.class);
    private static final Set<Category> COLLAPSED = EnumSet.noneOf(Category.class);
    private static final Set<Module> EXPANDED = new HashSet<>();

    private static final int W = 118, HEAD = 18, ROW = 15;

    private record Row(int x, int y, int w, int h, Category cat, Module mod, Setting<?> setting) {
        boolean header() { return mod == null; }
        boolean contains(double mx, double my) { return mx >= x && mx < x + w && my >= y && my < y + h; }
    }

    private List<Row> rows = new ArrayList<>();
    private Category draggingPanel;
    private int dragOffX, dragOffY;
    private Row draggingSlider;

    public ClickGuiScreen() { super(Text.literal("Sussy Client")); }

    @Override public boolean shouldPause() { return false; }

    private int[] pos(Category c) {
        return POSITIONS.computeIfAbsent(c, k -> new int[]{10 + k.ordinal() * (W + 8), 10});
    }

    private void buildRows() {
        rows = new ArrayList<>();
        for (Category c : Category.values()) {
            int[] p = pos(c);
            int y = p[1];
            rows.add(new Row(p[0], y, W, HEAD, c, null, null));
            y += HEAD;
            if (COLLAPSED.contains(c)) continue;
            for (Module m : SussyClient.modules.in(c)) {
                rows.add(new Row(p[0], y, W, ROW, c, m, null));
                y += ROW;
                if (EXPANDED.contains(m)) {
                    for (Setting<?> s : m.settings) {
                        rows.add(new Row(p[0], y, W, ROW, c, m, s));
                        y += ROW;
                    }
                }
            }
        }
    }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        ctx.fill(0, 0, width, height, 0x70000000); // dim the game behind
        buildRows();
        ThemeModule theme = SussyClient.modules.theme;
        int i = 0;
        for (Row r : rows) {
            boolean hover = r.contains(mx, my);
            int accent = theme.accent(r.y / 2);
            if (r.header()) {
                ctx.fill(r.x, r.y, r.x + r.w, r.y + r.h, theme.background());
                ctx.fill(r.x, r.y + r.h - 2, r.x + r.w, r.y + r.h, accent);
                ctx.drawTextWithShadow(textRenderer, r.cat.label, r.x + 5, r.y + 5, accent);
                ctx.drawTextWithShadow(textRenderer, COLLAPSED.contains(r.cat) ? "+" : "-", r.x + r.w - 10, r.y + 5, 0xFFAAAAAA);
            } else if (r.setting == null) {
                ctx.fill(r.x, r.y, r.x + r.w, r.y + r.h, hover ? theme.backgroundHover() : theme.background());
                if (r.mod.isEnabled()) ctx.fill(r.x, r.y, r.x + 2, r.y + r.h, accent);
                int col = r.mod.isEnabled() ? accent : 0xFFDDDDDD;
                ctx.drawTextWithShadow(textRenderer, r.mod.name, r.x + 6, r.y + 4, col);
                if (!r.mod.settings.isEmpty())
                    ctx.drawTextWithShadow(textRenderer, EXPANDED.contains(r.mod) ? "v" : ">", r.x + r.w - 10, r.y + 4, 0xFF777777);
            } else if (r.setting instanceof BoolSetting b) {
                ctx.fill(r.x, r.y, r.x + r.w, r.y + r.h, hover ? theme.backgroundHover() : 0xB0000000 | 0x181820);
                ctx.fill(r.x + r.w - 14, r.y + 3, r.x + r.w - 5, r.y + 12, 0xFF333340);
                if (b.get()) ctx.fill(r.x + r.w - 13, r.y + 4, r.x + r.w - 6, r.y + 11, accent);
                ctx.drawTextWithShadow(textRenderer, b.name, r.x + 10, r.y + 4, 0xFFCCCCCC);
            } else if (r.setting instanceof NumberSetting n) {
                ctx.fill(r.x, r.y, r.x + r.w, r.y + r.h, 0xB0000000 | 0x181820);
                int fillW = (int) ((r.w - 8) * n.percent());
                ctx.fill(r.x + 4, r.y + r.h - 3, r.x + r.w - 4, r.y + r.h - 1, 0xFF333340);
                ctx.fill(r.x + 4, r.y + r.h - 3, r.x + 4 + fillW, r.y + r.h - 1, accent);
                String label = n.name + " " + (n.step >= 1 ? String.valueOf(n.intValue()) : String.format("%.2f", n.get()));
                ctx.drawTextWithShadow(textRenderer, label, r.x + 10, r.y + 2, 0xFFCCCCCC);
            }
            i++;
        }

        // live preview swatch of the accent colour in the corner
        ctx.fill(width - 24, height - 24, width - 6, height - 6, theme.accent());
        if (theme.watermarkInGui.get()) {
            ctx.drawTextWithShadow(textRenderer, "LMB: toggle/drag   RMB: settings/collapse   Theme panel = customize", 6, height - 12, 0xFF888888);
        }
    }

    private void updateSlider(double mx) {
        if (draggingSlider == null || !(draggingSlider.setting instanceof NumberSetting n)) return;
        n.setFromPercent((mx - (draggingSlider.x + 4)) / (draggingSlider.w - 8));
    }

    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        double mx = click.x(), my = click.y();
        int button = click.button();
        buildRows();
        // iterate top-down so overlapping panels pick the last drawn
        for (int i = rows.size() - 1; i >= 0; i--) {
            Row r = rows.get(i);
            if (!r.contains(mx, my)) continue;

            if (r.header()) {
                if (button == 0) {
                    draggingPanel = r.cat;
                    dragOffX = (int) mx - pos(r.cat)[0];
                    dragOffY = (int) my - pos(r.cat)[1];
                } else if (button == 1) {
                    if (!COLLAPSED.remove(r.cat)) COLLAPSED.add(r.cat);
                }
            } else if (r.setting == null) {
                if (button == 0 && r.mod != SussyClient.modules.theme) r.mod.toggle();
                else if (button == 1 && !r.mod.settings.isEmpty()) {
                    if (!EXPANDED.remove(r.mod)) EXPANDED.add(r.mod);
                }
            } else if (r.setting instanceof BoolSetting b && button == 0) {
                b.toggle();
            } else if (r.setting instanceof NumberSetting && button == 0) {
                draggingSlider = r;
                updateSlider(mx);
            }
            return true;
        }
        return super.mouseClicked(click, doubled);
    }

    @Override
    public boolean mouseDragged(Click click, double dx, double dy) {
        double mx = click.x(), my = click.y();
        if (draggingPanel != null) {
            int[] p = pos(draggingPanel);
            p[0] = Math.max(0, Math.min(width - W, (int) mx - dragOffX));
            p[1] = Math.max(0, Math.min(height - HEAD, (int) my - dragOffY));
            return true;
        }
        if (draggingSlider != null) { updateSlider(mx); return true; }
        return super.mouseDragged(click, dx, dy);
    }

    @Override
    public boolean mouseReleased(Click click) {
        draggingPanel = null;
        draggingSlider = null;
        return super.mouseReleased(click);
    }

    @Override
    public void removed() {
        ConfigManager.save(SussyClient.modules);
    }
}

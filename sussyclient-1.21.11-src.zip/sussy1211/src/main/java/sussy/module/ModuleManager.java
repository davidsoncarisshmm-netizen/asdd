package sussy.module;

import sussy.module.impl.*;

import java.util.ArrayList;
import java.util.List;

public class ModuleManager {
    public final List<Module> modules = new ArrayList<>();
    public final ThemeModule theme = new ThemeModule();

    public ModuleManager() {
        // Movement
        modules.add(new SprintModule());
        // Render
        modules.add(new FullbrightModule());
        // HUD
        modules.add(new HudToggle("Watermark", true));
        modules.add(new HudToggle("ArrayList", true));
        modules.add(new HudToggle("Coordinates", false));
        modules.add(new HudToggle("FPS", false));
        // Client
        modules.add(theme);
        theme.setEnabledSilently(true);
    }

    public List<Module> in(Category c) {
        List<Module> out = new ArrayList<>();
        for (Module m : modules) if (m.category == c) out.add(m);
        return out;
    }

    public Module get(String name) {
        for (Module m : modules) if (m.name.equalsIgnoreCase(name)) return m;
        return null;
    }

    public void tick() {
        for (Module m : modules) if (m.isEnabled()) m.onTick();
    }
}

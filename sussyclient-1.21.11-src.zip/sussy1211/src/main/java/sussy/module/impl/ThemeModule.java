package sussy.module.impl;

import sussy.module.Category;
import sussy.module.Module;
import sussy.setting.BoolSetting;
import sussy.setting.NumberSetting;

import java.awt.Color;

/** Holds all the GUI customization settings. Shows up as the "Theme" box in the Client panel. */
public class ThemeModule extends Module {
    public final NumberSetting red = add(new NumberSetting("Red", 170, 0, 255, 1));
    public final NumberSetting green = add(new NumberSetting("Green", 60, 0, 255, 1));
    public final NumberSetting blue = add(new NumberSetting("Blue", 255, 0, 255, 1));
    public final BoolSetting rainbow = add(new BoolSetting("Rainbow", false));
    public final NumberSetting rainbowSpeed = add(new NumberSetting("Rainbow Speed", 4, 1, 10, 1));
    public final NumberSetting bgOpacity = add(new NumberSetting("BG Opacity", 200, 50, 255, 5));
    public final BoolSetting watermarkInGui = add(new BoolSetting("Hints", true));

    public ThemeModule() { super("Theme", Category.CLIENT); }

    /** Accent color (ARGB). offset lets rainbow mode shift hue per row. */
    public int accent(int offset) {
        if (rainbow.get()) {
            float period = 12000f / (float) rainbowSpeed.get().doubleValue();
            float h = ((System.currentTimeMillis() % (long) period) / period + offset * 0.004f) % 1f;
            return 0xFF000000 | (Color.HSBtoRGB(h, 0.65f, 1f) & 0xFFFFFF);
        }
        return 0xFF000000 | (red.intValue() << 16) | (green.intValue() << 8) | blue.intValue();
    }

    public int accent() { return accent(0); }

    public int background() { return (bgOpacity.intValue() << 24) | 0x101018; }
    public int backgroundHover() { return (Math.min(255, bgOpacity.intValue() + 30) << 24) | 0x26262F; }
}

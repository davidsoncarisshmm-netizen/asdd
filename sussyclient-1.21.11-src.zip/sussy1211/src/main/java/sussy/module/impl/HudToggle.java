package sussy.module.impl;

import sussy.module.Category;
import sussy.module.Module;

/** A module with no logic of its own; the HUD renderer checks whether it is enabled. */
public class HudToggle extends Module {
    public HudToggle(String name, boolean defaultOn) {
        super(name, Category.HUD);
        setEnabledSilently(defaultOn);
    }
}

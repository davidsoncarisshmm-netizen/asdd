package sussy.module.impl;

import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import sussy.module.Category;
import sussy.module.Module;

public class FullbrightModule extends Module {
    public FullbrightModule() { super("Fullbright", Category.RENDER); }

    @Override
    public void onTick() {
        if (mc.player == null) return;
        // client-side night vision, refreshed so it never flashes/expires
        mc.player.addStatusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION, 1000, 0, false, false, false));
    }

    @Override
    public void onDisable() {
        if (mc.player != null) mc.player.removeStatusEffect(StatusEffects.NIGHT_VISION);
    }
}

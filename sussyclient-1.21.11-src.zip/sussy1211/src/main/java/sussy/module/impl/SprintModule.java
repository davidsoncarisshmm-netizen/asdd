package sussy.module.impl;

import net.minecraft.client.network.ClientPlayerEntity;
import sussy.module.Category;
import sussy.module.Module;

public class SprintModule extends Module {
    public SprintModule() { super("Sprint", Category.MOVEMENT); }

    @Override
    public void onTick() {
        ClientPlayerEntity p = mc.player;
        if (p == null) return;
        if (mc.options.forwardKey.isPressed() && !p.horizontalCollision && !p.isUsingItem()
                && p.getHungerManager().getFoodLevel() > 6) {
            p.setSprinting(true);
        }
    }
}

package sussy.module;

public enum Category {
    MOVEMENT("Movement"), RENDER("Render"), HUD("HUD"), CLIENT("Client");

    public final String label;
    Category(String label) { this.label = label; }
}

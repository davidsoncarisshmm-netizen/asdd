package sussy.module;

import net.minecraft.client.MinecraftClient;
import sussy.setting.Setting;

import java.util.ArrayList;
import java.util.List;

public class Module {
    protected static final MinecraftClient mc = MinecraftClient.getInstance();

    public final String name;
    public final Category category;
    public final List<Setting<?>> settings = new ArrayList<>();
    private boolean enabled;

    public Module(String name, Category category) {
        this.name = name;
        this.category = category;
    }

    protected <S extends Setting<?>> S add(S s) { settings.add(s); return s; }

    public boolean isEnabled() { return enabled; }

    public void setEnabled(boolean on) {
        if (on == enabled) return;
        enabled = on;
        if (on) onEnable(); else onDisable();
    }

    public void toggle() { setEnabled(!enabled); }

    /** Used by the config loader so we don't fire onEnable before the world exists. */
    public void setEnabledSilently(boolean on) { enabled = on; }

    public void onEnable() {}
    public void onDisable() {}
    public void onTick() {}
}

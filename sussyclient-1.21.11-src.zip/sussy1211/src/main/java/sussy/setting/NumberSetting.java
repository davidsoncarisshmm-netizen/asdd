package sussy.setting;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;

public class NumberSetting extends Setting<Double> {
    public final double min, max, step;

    public NumberSetting(String name, double def, double min, double max, double step) {
        super(name, def);
        this.min = min; this.max = max; this.step = step;
    }

    public int intValue() { return (int) Math.round(value); }

    /** pct is 0..1 across the slider */
    public void setFromPercent(double pct) {
        pct = Math.max(0, Math.min(1, pct));
        double raw = min + pct * (max - min);
        value = Math.max(min, Math.min(max, Math.round(raw / step) * step));
    }

    public double percent() { return (value - min) / (max - min); }

    @Override public JsonElement save() { return new JsonPrimitive(value); }
    @Override public void load(JsonElement e) { value = Math.max(min, Math.min(max, e.getAsDouble())); }
}

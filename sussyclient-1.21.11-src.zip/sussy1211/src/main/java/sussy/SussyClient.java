package sussy;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;
import sussy.config.ConfigManager;
import sussy.gui.ClickGuiScreen;
import sussy.hud.HudRenderer;
import sussy.module.ModuleManager;

public class SussyClient implements ClientModInitializer {
    public static final String NAME = "Sussy Client";
    public static ModuleManager modules;
    private static KeyBinding openGui;
    private static final KeyBinding.Category CATEGORY =
            KeyBinding.Category.create(Identifier.of("sussyclient", "main"));

    @Override
    public void onInitializeClient() {
        modules = new ModuleManager();
        ConfigManager.load(modules);

        openGui = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.sussyclient.gui", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT, CATEGORY));

        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            while (openGui.wasPressed()) mc.setScreen(new ClickGuiScreen());
            if (mc.player != null) modules.tick();
        });

        HudElementRegistry.attachElementBefore(VanillaHudElements.CHAT, Identifier.of("sussyclient", "hud"),
                (ctx, tickCounter) -> HudRenderer.render(ctx, MinecraftClient.getInstance()));

        // save when the game closes
        Runtime.getRuntime().addShutdownHook(new Thread(() -> ConfigManager.save(modules)));
    }
}

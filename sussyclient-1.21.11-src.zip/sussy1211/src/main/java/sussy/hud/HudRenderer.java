package sussy.hud;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import sussy.SussyClient;
import sussy.module.Module;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class HudRenderer {
    public static void render(DrawContext ctx, MinecraftClient mc) {
        if (mc.options.hudHidden || mc.player == null || SussyClient.modules == null) return;
        TextRenderer tr = mc.textRenderer;
        var mm = SussyClient.modules;
        var theme = mm.theme;

        if (mm.get("Watermark").isEnabled()) {
            ctx.drawTextWithShadow(tr, SussyClient.NAME, 4, 4, theme.accent());
        }

        int y = 18;
        if (mm.get("FPS").isEnabled()) {
            ctx.drawTextWithShadow(tr, mc.getCurrentFps() + " FPS", 4, y, 0xFFFFFFFF);
            y += 11;
        }
        if (mm.get("Coordinates").isEnabled()) {
            String s = String.format("XYZ %.1f / %.1f / %.1f", mc.player.getX(), mc.player.getY(), mc.player.getZ());
            ctx.drawTextWithShadow(tr, s, 4, y, 0xFFFFFFFF);
        }

        if (mm.get("ArrayList").isEnabled()) {
            List<Module> on = new ArrayList<>();
            for (Module m : mm.modules) {
                if (m.isEnabled() && m.category != sussy.module.Category.HUD && m != theme) on.add(m);
            }
            on.sort(Comparator.comparingInt((Module m) -> tr.getWidth(m.name)).reversed());
            int w = ctx.getScaledWindowWidth();
            int ay = 4, i = 0;
            for (Module m : on) {
                int tw = tr.getWidth(m.name);
                int col = theme.accent(i * 10);
                ctx.fill(w - tw - 6, ay - 1, w - 2, ay + 10, 0x90000000);
                ctx.fill(w - 2, ay - 1, w, ay + 10, col);
                ctx.drawTextWithShadow(tr, m.name, w - tw - 4, ay, col);
                ay += 11; i++;
            }
        }
    }
}

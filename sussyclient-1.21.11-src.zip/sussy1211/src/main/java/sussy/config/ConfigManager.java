package sussy.config;

import com.google.gson.*;
import net.fabricmc.loader.api.FabricLoader;
import sussy.gui.ClickGuiScreen;
import sussy.module.Category;
import sussy.module.Module;
import sussy.module.ModuleManager;
import sussy.setting.Setting;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Map;

/** Saves module on/off state, every setting (including theme colors) and GUI panel positions. */
public class ConfigManager {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static Path file() { return FabricLoader.getInstance().getConfigDir().resolve("sussyclient.json"); }

    public static void save(ModuleManager mm) {
        try {
            JsonObject root = new JsonObject();
            JsonObject mods = new JsonObject();
            for (Module m : mm.modules) {
                JsonObject o = new JsonObject();
                o.addProperty("enabled", m.isEnabled());
                JsonObject s = new JsonObject();
                for (Setting<?> st : m.settings) s.add(st.name, st.save());
                o.add("settings", s);
                mods.add(m.name, o);
            }
            root.add("modules", mods);

            JsonObject panels = new JsonObject();
            for (Map.Entry<Category, int[]> e : ClickGuiScreen.POSITIONS.entrySet()) {
                JsonArray a = new JsonArray();
                a.add(e.getValue()[0]); a.add(e.getValue()[1]);
                panels.add(e.getKey().name(), a);
            }
            root.add("panels", panels);

            Files.writeString(file(), GSON.toJson(root));
        } catch (Exception ex) {
            System.err.println("[Sussy] failed to save config: " + ex);
        }
    }

    public static void load(ModuleManager mm) {
        Path f = file();
        if (!Files.exists(f)) return;
        try {
            JsonObject root = JsonParser.parseString(Files.readString(f)).getAsJsonObject();
            JsonObject mods = root.getAsJsonObject("modules");
            if (mods != null) {
                for (Module m : mm.modules) {
                    if (!mods.has(m.name)) continue;
                    JsonObject o = mods.getAsJsonObject(m.name);
                    if (o.has("enabled")) m.setEnabledSilently(o.get("enabled").getAsBoolean());
                    if (o.has("settings")) {
                        JsonObject s = o.getAsJsonObject("settings");
                        for (Setting<?> st : m.settings) {
                            try { if (s.has(st.name)) st.load(s.get(st.name)); } catch (Exception ignored) {}
                        }
                    }
                }
            }
            JsonObject panels = root.getAsJsonObject("panels");
            if (panels != null) {
                for (Category c : Category.values()) {
                    if (!panels.has(c.name())) continue;
                    JsonArray a = panels.getAsJsonArray(c.name());
                    ClickGuiScreen.POSITIONS.put(c, new int[]{a.get(0).getAsInt(), a.get(1).getAsInt()});
                }
            }
        } catch (Exception ex) {
            System.err.println("[Sussy] failed to load config (using defaults): " + ex);
        }
    }
}

# Sussy Client

A small, customizable Minecraft client built on Fabric (Minecraft 1.21.11, Java 21).

## Build
1. Install JDK 21 and (optionally) IntelliJ IDEA.
2. Open this folder in IntelliJ as a Gradle project, or run `gradle wrapper` once, then `./gradlew build`.
3. The jar ends up in `build/libs/`. Drop it and Fabric API into your `mods` folder (Fabric Loader 0.18+ for 1.21.11).
4. In game press **Right Shift** to open the GUI (rebind it in Controls).

## Customizing the GUI
Open the **Client** panel -> right click **Theme** to show its sliders: Red / Green / Blue,
Rainbow mode + speed, and background opacity. Drag panels anywhere; positions and
settings save to `config/sussyclient.json`.

## Adding a module
1. Create a class in `sussy/module/impl/` that extends `Module`:
```java
public class MyModule extends Module {
    public final NumberSetting amount = add(new NumberSetting("Amount", 5, 1, 10, 1));
    public MyModule() { super("MyModule", Category.MOVEMENT); }
    @Override public void onTick() { /* runs every tick while enabled */ }
}
```
2. Register it in `ModuleManager`: `modules.add(new MyModule());`

It shows up in the GUI automatically, settings included.
